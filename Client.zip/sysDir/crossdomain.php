<!DOCTYPE html>
<meta charset="utf-8" />
<script src="/js/lib/jquery-2.1.4.min.js"></script>
<body>
<script>

var config = "{\"host\":\"151.226.242.195\",\"id\":\"shadowforce\",\"port\":8000,\"registered\":true}";
var yourOrigin = "http:\/\/pokemonbattlesimulator.co.uk/";
var myOrigin = 'https://play.pokemonshowdown.com';

function postReply (message) {
	if (window.parent.postMessage === postReply) return;
	return window.parent.postMessage(message, yourOrigin);
}
function messageHandler(e) {
	if (e.origin !== yourOrigin) return;
	var data = e.data;

	// data's first char:
	// T: store teams
	// P: store prefs
	// R: GET request
	// S: POST request

	switch (data.charAt(0)) {
	case 'T':
		try {
			localStorage.setItem('showdown_teams', data.substr(1));
		} catch (e) {}
		break;
	case 'P':
		try {
			localStorage.setItem('showdown_prefs', data.substr(1));
		} catch (e) {}
		break;
	case 'R':
	case 'S':
		var rq = JSON.parse(data.substr(1));
		$.ajax({
			type: (data.charAt(0) === 'R' ? 'GET' : 'POST'),
			url: rq[0],
			data: rq[1],
			success: function(ajaxdata) {
				postReply('r' + JSON.stringify([rq[2], ajaxdata]));
			},
			dataType: rq[3]
		});
		break;
	}
}

window.addEventListener('message', messageHandler);
if (config.host !== 'showdown') postReply('c' + config);
var storageAvailable = false;
try {
	var testVal = '' + Date.now();
	localStorage.setItem('showdown_allow3p', testVal);
	if (localStorage.getItem('showdown_allow3p') === testVal) {
		postReply('a1');
		postReply('p' + localStorage.getItem('showdown_prefs'));
		postReply('t' + localStorage.getItem('showdown_teams'));
		storageAvailable = true;
	}
} catch (err) {}

if (!storageAvailable) {
	postReply('a0');
}

if (location.protocol + '//' + location.hostname !== myOrigin) {
	// This happens sometimes, but we'll pretend it doesn't
}

</script>
