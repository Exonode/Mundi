<?php
include '../pokemonshowdown.com/news/embed.php';
